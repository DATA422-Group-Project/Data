
The varaibles in the DataFrame.csv:
"country" This is the country's name.
"urbanisation_rate" This is the urbanisation rate, which is the percentage of the population that lives in urban areas.
"urbanisation_yearly_change" This is the average rate that the urbanisation rate has been changing every year averaged over the last 20 years.
"gdp_per_cap" This is the real GDP per capita rate, the real means this variable is based on purchasing power.
"size" This is the size of the country in squared kilometres. 
"population" This is the population size for 2021
"density" This is the number of people that live in an average square kilometre.
"country code" This is the three-letter code representing the country.