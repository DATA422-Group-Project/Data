fips: 2 letter FIPS country code

tavg: Average temperature 2021 & 2020 (degrees Celsius).

prcp: Average daily precipitation 2021 & 2020 (milimeters).

iso3166: 2 character ISO-3166 country code.

Name: Country name.