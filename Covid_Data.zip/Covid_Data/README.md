#COVID-19 Vaccination rates for the latest date(22/10/2021) and OECD countries


#Variables in COVID-19 Vaccination rates 
country_code - ISO-3 Character 
country_name - Country name
region - Country in a specific region, as WHO Member States are grouped into six regions
total_cases - Total number of COVID-19 cases 
total_deaths  - Total number of deaths due to COVID-19 
total_vaccinations - Total number of vaccinations administered for COVID-19 
vaccinated_1dose - Total number of people vaccinated by single dose 
fully_vacccinated - Total number of people fully vaccinated
total_vaccinations_per100 - Total number of vaccinations per 100 people in total population
percent_full_vac - Percentage of people fully vaccinated
first_vaccine_date - Vaccination start date by country
last_updated_date - Last updated date
stringency - Stringency index is the measure from 0 to 100 based on ordinal calculations of people’s behaviour in terms of lockdowns during the pandemic. Like social distancing, facemasks, hand hygiene, banning or limited public place gatherings, closures of schools, parks and work places, economic aids, prioritising the vaccinations are some of the measures taken to minimise the spread of infection and mortalities in the community. 

#variables in OECD members
country_code - ISO-3 Character 
country_name - Country name

#Data Sourced from
https://covid19.who.int/WHO-COVID-19-global-table-data.csv 
https://covid19.who.int/who-data/vaccination-data.csv 
https://covidtrackerapi.bsg.ox.ac.uk/api/v2/stringency/date-range/{YYYY-MM-DD}/{YYYY-MM-DD}
https://www.oecd.org/about/members-and-partners/



  

